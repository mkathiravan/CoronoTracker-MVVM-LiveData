package net.kathir.livedata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    SwipeRefreshLayout swipeRefresh;
    private MainViewModel mainViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializationViews();
        mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        getRegionalData();
    }

    private void getRegionalData() {
        swipeRefresh.setRefreshing(true);
        mainViewModel.getAllRegional().observe(this, new Observer<List<RegionalModel>>() {
            @Override
            public void onChanged(List<RegionalModel> regionalModelsList) {
                swipeRefresh.setRefreshing(false);
                prepareRecycelrView(regionalModelsList);
            }
        });
    }

    private void prepareRecycelrView(List<RegionalModel> regionalModelsList) {
    }

    private void initializationViews() {
        swipeRefresh = findViewById(R.id.swiperefresh);
        mRecyclerView = findViewById(R.id.blogRecyclerView);
    }
}
