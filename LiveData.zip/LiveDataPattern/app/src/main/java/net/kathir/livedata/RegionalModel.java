package net.kathir.livedata;

import com.google.gson.annotations.SerializedName;

public class RegionalModel {

    @SerializedName("loc")
    private String loc;

    @SerializedName("confirmedCasesIndian")
    private int confirmedCasesIndian;

    @SerializedName("discharged")
    private int discharged;

    @SerializedName("deaths")
    private int deaths;

    @SerializedName("confirmedCasesForeign")
    private int confirmedCasesForeign;

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public int getConfirmedCasesIndian() {
        return confirmedCasesIndian;
    }

    public void setConfirmedCasesIndian(int confirmedCasesIndian) {
        this.confirmedCasesIndian = confirmedCasesIndian;
    }

    public int getDischarged() {
        return discharged;
    }

    public void setDischarged(int discharged) {
        this.discharged = discharged;
    }

    public int getDeaths() {
        return deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }

    public int getConfirmedCasesForeign() {
        return confirmedCasesForeign;
    }

    public void setConfirmedCasesForeign(int confirmedCasesForeign) {
        this.confirmedCasesForeign = confirmedCasesForeign;
    }


}
