package net.kathir.livedata;

public class RegionalAdapter extends  {
}
